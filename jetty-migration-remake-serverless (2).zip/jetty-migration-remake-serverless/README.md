# Jetty Migration Project

## How to Serverless

1. Install Serverless. Instructions - [getting-started](https://www.serverless.com/framework/docs/getting-started)

2. Install Plugins. Instructions - [guides/plugins](https://www.serverless.com/framework/docs/guides/plugins)

3. Initialize Serverless via `serverless` in CMD inside the project folder (where the `serverless.yml` is) 
    - Registered in the __Serverless Dashboard__ 
    - Add a Cloud Provider (AWS here), go with manual option
    - For closer info how to register/add provider/deploy check the following:
    [tutorial](https://www.serverless.com/framework/docs/tutorial)
    [adding AWS credentials](https://www.serverless.com/framework/docs/tutorial)
4. Run `serverless deploy` for the lambda function to be deployed. 

__Note A__: If you facing the AWS recource permission issues, do as follows:

1. Create new IAM User (service account) `IAM -> Users -> Create User`
2. Add the following permissions
    - AmazonAPIGatewayAdministrator
    - AmazonS3FullAccess
    - AWSCloudFormationFullAccess
    - AWSLambda_FullAccess
    - AWSStepFunctionsFullAccess
    - CloudWatchLogsFullAccess
    - IAMFullAccess
3. Export Security Credentials `user-name -> Security Credentials -> Access Keys`
4. Create a Provider inside the `Serverless Dashboard` with exported credentials. 

__Note B__: If still facing the AWS recource permission issues, check the whether you (service account) are(is) authorized to manipulate the resources within region in `serverless.yml`








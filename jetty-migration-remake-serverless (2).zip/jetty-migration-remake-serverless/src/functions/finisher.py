def finish_migration(event, context):
    """
    Finish the migration process
    """
    # TODO
    # Finishe the Migration process
    # Publish message to SQS
    print("Finishing migration process...")
    return {"statusCode": 200, "body": "Finishing migration process..."}

import json

from src.common.entities import Renewal
from src.common.requests import CreateRenewal, IssueRenewal


def handle(event, context):
    """
    AWS lambda function to create and issue a renewal in Socotra.
    """
    # TODO
    # Retrieve Renewal(s) From SF
    # Serialize
    # Send Create Request to Socotra
    # Send Issue Request to Socotra
    # Log Message

    return {"statusCode": 200, "body": "Renewal created and issued"}

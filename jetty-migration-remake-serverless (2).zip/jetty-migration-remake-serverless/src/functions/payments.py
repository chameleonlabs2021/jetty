import json

from src.common.entities import Invoice
from src.common.requests import FetchPolicyInvoices, PayInvoice


def handle(event, context):
    """
    AWS lambda function to issue invoices for policy and pay them in Socotra.
    """
    # TODO
    # Fetch Invoices from Socotra
    # Pay Invoices
    # Log Message

    return {"statusCode": 200, "body": "Payments Issued and Payed"}

import json
from loguru import logger

from src.common.authorization_manager import SocotraAuthorizationManager
from src.common.entities import AuxData, DepositPolicy, ProtectPolicy
from src.common.requests import CreateAuxData, CreatePolicy
from src.common.transfer_object import (
    PolicyHolderOutputObject,
    PolicyMigrationStatus,
    PolicyOutputObject,
)


def handle(event, context):
    """
    AWS lambda function to create a policyholder in Socotra

    input: PolicyHolder ID
    output: HTTP Response status
    """
    # TODO
    # Retrieve Policy from SF (one)
    # Serialize Policy
    # Send a Request to Socotra
    # Handle the Response
    # Log Message
    # Submit Key Pair
    # Serialize AUX Data
    # Send AUXData to Socotra
    # Issue Policy (POST Socotra)
    # Extract Invoice IDs (GET Socotra)

    dev = False
    try:
        if isinstance(event, dict) and "body" in event.keys():
            dev = True
            input = PolicyHolderOutputObject.model_validate(eval(event["body"]))
        else:
            input = PolicyHolderOutputObject.model_validate(event)
    except Exception as e:
        print(e)
        # TODO: finish the flow
        return {"statusCode": 400, "output": "No final response"}

    ph_locator = input.policyholder_locator
    custom_policy_number = input.policy_locator

    # 1.a
    ph1_policy_protect = ProtectPolicy.model_validate_json(
        """
    {
        "finalize": false,
        "productName": "Protect",
        "policyholderLocator": "d682d2a8-47ad-45e9-a1db-4be949b4fd4b",
        "policyStartTimestamp": 1689836559000,
        "policyEndTimestamp": 1719350177000,
        "currency": "USD",
        "autofill": [],
        "paymentScheduleName": "monthly",
        "fieldValues": {
            "rater_source": "AA1538",
            "rater_id": "AA1538",
            "custom_policy_number": "AA1538",
            "policy_term": 0,
            "auto_renewal_status": "renew",
            "number_significant_others": 1,
            "all_peril_deductible": 250,
            "has_restricted_dog_breed": "no",
            "superior_construction": "no",
            "protective_devices": "police/fire station reporting burglar/fire alarm",
            "prior_claims": "0",
            "number_of_units_in_building": "two units",
            "building_code_effectiveness_grade": "5",
            "construction_type": "frame",
            "items_to_schedule": "yes"
        },
        "fieldGroups": [
            {
                "fieldName": "building_details",
                "fieldValues": {
                    "address_line_1": "4526 Douglas Drives",
                    "address_line_2": "700 Cronin Vista",
                    "address_city": "North Ali",
                    "address_state": "NY",
                    "address_zip": "10004",
                    "address_county": "New York County",
                    "building_id": "k",
                    "sfdc_property_id_at_purchase": "7",
                    "iso_territory_code": "5",
                    "iso_protection_class": "7"
                }
            },
            {
                "fieldName": "non_primary_policy_holders",
                "fieldValues": {
                    "non_primary_name": "Lynn Kub",
                    "non_primary_email": "Bernhard.Smitham@gmail.com",
                    "non_primary_phone": "668-474-8368",
                    "non_primary_dob": "2000-01-01",
                    "non_primary_custom_member_id": "AA1538",
                    "non_primary_relationship": "spouse_named_insured"
                }
            },
            {
                "fieldName": "addl_interests",
                "fieldValues": {
                    "addl_interest_name": "Vicente",
                    "addl_interest_email": "Gerald_Abbott57@hotmail.com",
                    "addl_interest_address_line_1": "3765 Feest Crossing",
                    "addl_interest_address_line_2": "1120 Lauryn Loop",
                    "addl_interest_address_city": "New Bufordland",
                    "addl_interest_address_state": "NY",
                    "addl_interest_address_zip": "10004"
                }
            }
        ],
        "exposures": {
            "exposureName": "property",
            "perils": [
                {
                    "name": "coverage_c_contents",
                    "deductible": 200
                },
                {
                    "name": "coverage_d_loss_of_use",
                    "deductible": 500
                }
            ]
        }
    }
    """
    )

    ph1_policy_protect_aux = AuxData.model_validate_json(
        """
        {
            "auxData": [
                {
                    "key": "policy_status",
                    "value": "Active"
                },
                {
                    "key": "notes",
                    "value": "This is a test note"
                },
                {
                    "key": "has_balance_due",
                    "value": true
                },
                {
                "key": "stripe_card_decline_reason",
                "value": "some very important reason" 
                },
                {
                "key": "stripe_payment_id",
                "value": "some-payment-id-12234234"
                },
                {
                "key": "stripe_source_id",
                "value": "some-source-id-12234234"
                },
                {
                "key": "migration_brightcore_timestamp",
                "value": "1687978291000"
                }
            ]
        }
        """
    )

    with SocotraAuthorizationManager(
        auth_method="token",
        auth_token=input.socotra_token,
        expiration_time=input.socotra_token_expiration,
    ) as socotra:
        # Create Policy
        create_policy = CreatePolicy(entity=ph1_policy_protect, locator=ph_locator)
        socotra_response = socotra.request(create_policy)

        if str(socotra_response.status_code).startswith("2"):
            migration_status = PolicyMigrationStatus.IN_PROGRESS
            output = PolicyOutputObject.from_response(
                response=socotra_response,
                migration_status=migration_status,
                policyholder_locator=ph_locator,
                snowflake_input=ph1_policy_protect.model_dump(),
                custom_policy_number=custom_policy_number,
                socotra_token=input.socotra_token,
                socotra_token_expiration=input.socotra_token_expiration,
            )
            policy_locator = output.policy.locator
        else:
            migration_status = PolicyMigrationStatus.FAILED
            return {
                "statusCode": socotra_response.status_code,
                "output": socotra_response.response.json(),
            }

        # Create AUX Data
        create_aux = CreateAuxData(
            entity=ph1_policy_protect_aux, locator=policy_locator
        )
        aux_response = socotra.request(create_aux)

        if str(aux_response.status_code).startswith("2"):
            output.add_auxdata(aux_response)
        else:
            migration_status = PolicyMigrationStatus.FAILED
            return {
                "statusCode": aux_response.status_code,
                "output": aux_response.response.json(),
            }

    if dev:
        response = {
            "statusCode": socotra_response.status_code,
            "body": "{body}".format(body = json.dumps(json.loads(output.model_dump_json()))),
        }
        
        logger.debug(response)
        return response

    return {
        "statusCode": socotra_response.status_code,
        "output": json.loads(output.model_dump_json()),
    }

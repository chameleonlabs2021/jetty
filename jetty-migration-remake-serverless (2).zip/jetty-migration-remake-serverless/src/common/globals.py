import os

from dotenv import load_dotenv

# load_dotenv(dotenv_path="./settings/local/.env", verbose=True)

SOCOTRA_URL = os.getenv("SOCOTRA_URL")
SOCOTRA_HOSTNAME = os.getenv("SOCOTRA_HOSTNAME")
SOCOTRA_USERNAME = os.getenv("SOCOTRA_USERNAME")
SOCOTRA_PASSWORD = os.getenv("SOCOTRA_PASSWORD")

SOCOTRA_IDP_URL = os.getenv("SOCOTRA_IDP_URL")
SOCOTRA_IDP_REALM = os.getenv("SOCOTRA_IDP_REALM")
JETTY_SOCOTRA_CLIENT_ID = os.getenv("JETTY_SOCOTRA_CLIENT_ID")
JETTY_SOCOTRA_CLIENT_SECRET = os.getenv("JETTY_SOCOTRA_CLIENT_SECRET")


SF_USERNAME = os.getenv("SF_USERNAME")
SF_PASSWORD = os.getenv("SF_PASSWORD")
SF_TOKEN = os.getenv("SF_TOKEN")

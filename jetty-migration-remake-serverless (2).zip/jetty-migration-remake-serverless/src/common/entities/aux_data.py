from datetime import datetime
from enum import Enum
from typing import Annotated, Literal, Union

from pydantic import Field, validator

from .base_entity import BaseModel, BaseSocotraEntity


class KVPair(BaseModel):
    key: str
    value: str | None = None
    uiType: Literal["normal", "hidden", "readonly"] | None = None


class StripeFields(BaseModel):
    key: Literal["stripe_card_decline_reason", "stripe_payment_id", "stripe_source_id"]
    value: str
    uiType: Literal["normal", "hidden", "readonly"] | None = None


class Notes(BaseModel):
    key: Literal["notes"]
    value: str
    uiType: Literal["normal", "hidden", "readonly"] | None = None


class MigrationBrightCoreTimestamp(BaseModel):
    key: Literal["migration_brightcore_timestamp"]
    value: datetime

    @validator("value", pre=True)
    def str_to_datetime(cls, v):
        if isinstance(v, str) and "T" in v:
            return datetime.fromisoformat(v)
        elif isinstance(v, (str, int)):
            return datetime.fromtimestamp(int(v) / 1000)
        return v


class PolicyStatus(BaseModel):
    key: Literal["policy_status"]
    value: Literal[
        "Active",
        "Canceled",
        "Draft",
        "Cancellation Pending",
        "non-payment of premium",
        "Expired",
    ]
    uiType: Literal["normal", "hidden", "readonly"] | None = None


class HasBalanceDue(BaseModel):
    key: Literal["has_balance_due"]
    value: bool


AuxDataItem = Annotated[
    Union[
        StripeFields, Notes, MigrationBrightCoreTimestamp, PolicyStatus, HasBalanceDue
    ],
    Field(discriminator="key"),
]


class AuxData(BaseSocotraEntity):
    auxData: list[AuxDataItem] | None = None

from datetime import datetime
from typing import Optional

from pydantic import BaseModel


class BaseSocotraEntity(BaseModel):
    @property
    def class_name(self):
        return self.__class__.__name__

    @property
    def id(self):
        ...

    class Config:
        json_encoders = {
            datetime: lambda t: int(t.timestamp() * 1000),
        }


class Search(BaseSocotraEntity):
    searchString: str


FieldValues = dict


class FieldGroupItemBase(BaseModel):
    fieldName: str
    fieldValues: FieldValues = None


class UpdateFieldGroupItem(FieldGroupItemBase):
    fieldGroupLocator: str
    fieldName: str | None = None
    fieldValues: FieldValues | None = None


class Peril(BaseModel):
    name: str
    deductible: int | None = None


class Exposure(BaseModel):
    exposureName: str = "exposure"

    fieldValues: FieldValues | None = None
    fieldGroups: list[FieldGroupItemBase] | None = None
    perils: list[Peril] | Peril | None = None


class UpdateExposure(Exposure):
    fieldValues: FieldValues
    addFieldGroups: list[FieldGroupItemBase]
    updateFieldGroups: list[UpdateFieldGroupItem]
    removeFieldGroups: list[str]

    # perils missing

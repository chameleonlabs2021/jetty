from datetime import date, datetime
from typing import Annotated, List, Literal, Union
from uuid import UUID

from pydantic import Field, conint, validator

from .base_entity import *

PRODUCT_NAMES = Literal["Deposit-Dynamic", "Deposit-Fixed", "Protect"]


########### Literals ###########

DEPOSIT_PAYMENT_OPTION = Literal["monthly", "upfront"]
PROTECT_PAYMENT_OPTION = Literal["monthly", "annually"]

GroupItemNames = Literal[
    "addl_interests",
    "non_primary_policy_holders",
    "building_details",
]

PROTECTIVE_DEVICES = Literal[
    "na",
    "central station reporting burglar/fire alarm",
    "police/fire station reporting burglar/fire alarm",
    "automatic aprinklers - all areas",
    "automatic sprinklers - main areas",
    "local burglar/fire alarm",
]

DEPOSIT_CANCELATION_REASON = Literal[
    "mid_lease - claim eligible",
    "moveout - claim eligible",
    "cancel_flat, general - claim eligible",
    "cancel_flat - rewrite",
    "lease_not_signed - claim not eligible",
    "cash_deposit_posted - claim not eligible",
    "fraud - claim not eligible",
]

PROTECT_CANCELATION_REASON = Literal[
    "expired",
    "canceled by member",
    "canceled for non-payment of premium",
    "canceled flat",
    "canceled_flat - rewrite",
    "fraudd",
    "other",
]


########### Policy Field Values ###########
class DepositPolicyFieldValues(BaseModel):
    rater_source: str | None = None
    rater_id: str | None = None

    custom_policy_number: str
    policy_term: int
    auto_renewal_status: Literal["renew", "non-renew"]
    rewritten: bool | None = None
    credit_score: str

    previous_policy_locator: str | None = None
    previous_policy_start_date: date | None = None
    # Below are NOT present in config
    policy_cancellation_reason: DEPOSIT_CANCELATION_REASON | None = None
    socotra_policy_holder_locator_id: str | None = None


class ProtectPolicyFieldValues(BaseModel):
    rater_source: str | None = None
    rater_id: str | None = None
    custom_policy_number: str
    policy_term: int | float
    prior_claims: Literal["0", "1", "2", "3", "4 or more"] | None = None
    auto_renewal_status: Literal["renew", "non-renew"]
    rewritten: bool | None = None

    number_significant_others: int | None = None
    all_peril_deductible: int
    has_restricted_dog_breed: Literal["yes", "no"]
    superior_construction: Literal["yes", "no"]
    protective_devices: PROTECTIVE_DEVICES | List[PROTECTIVE_DEVICES]
    number_of_units_in_building: Literal[
        "single family",
        "two units",
        "three units",
        "four or more units",
    ]
    building_code_effectiveness_grade: Literal[
        "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Ungraded"
    ] | None = None
    construction_type: Literal["frame", "masonry"] = None
    items_to_schedule: Literal["yes", "no"]
    # Below are NOT present in config
    protective_devices_group: str | None = None
    claim_eligible: Literal["yes", "no"] | None = None
    policy_cancellation_reason: PROTECT_CANCELATION_REASON | None = None
    socotra_policy_holder_locator_id: str | None = None


########### Policy Group fields ###########


###### Building Details ######
class BuidlingDetails(BaseModel):
    address_line_1: str
    address_line_2: str | None = None
    address_city: str
    address_state: str
    address_zip: str
    address_county: str | None = None
    building_id: str | None = None
    sfdc_property_id_at_purchase: str | None = None


class ProtectBuildingDetails(BuidlingDetails):
    iso_territory_code: str
    iso_protection_class: str


class DepositPolicyBuildingFieldGroupItem(FieldGroupItemBase):
    fieldName: Literal["building_details"]
    fieldValues: BuidlingDetails


class ProtectPolicyBuildingFieldGroupItem(FieldGroupItemBase):
    fieldName: Literal["building_details"]
    fieldValues: ProtectBuildingDetails


###### Non Primary Policy Holder ######
class NonPrimaryPolicyHolder(BaseModel):
    non_primary_name: str
    non_primary_email: str
    non_primary_phone: str
    non_primary_dob: date
    non_primary_custom_member_id: str | None = None
    non_primary_relationship: str | Literal[
        "spouse_named_insured", "significant_other"
    ] | None = None
    # non_primary_credit_score: int | None = None  Only for Deposit-Fixed


class NonPrimaryPolicyHolderFieldGroupItem(FieldGroupItemBase):
    fieldName: Literal["non_primary_policy_holders"]
    fieldValues: NonPrimaryPolicyHolder


###### Addl Interest ######
class AddlInterest(BaseModel):
    addl_interest_name: str
    addl_interest_email: str | None = None
    addl_interest_address_line_1: str | None = None
    addl_interest_address_line_2: str | None = None
    addl_interest_address_city: str | None = None
    addl_interest_address_state: str | None = None
    addl_interest_address_zip: str | None = None


class AddlInterestFieldGroupItem(FieldGroupItemBase):
    fieldName: Literal["addl_interests"]
    fieldValues: AddlInterest


####### Protective Devices #######
class ProtectiveDevices(BaseModel):
    protective_devices: List[PROTECTIVE_DEVICES] | PROTECTIVE_DEVICES | None = None


class ProtectiveDevicesFieldGroupItem(FieldGroupItemBase):
    fieldName: Literal["protective_devices"]
    fieldValues: ProtectiveDevices


DepositPolicyFieldGroupItem = Annotated[
    Union[
        DepositPolicyBuildingFieldGroupItem,
        NonPrimaryPolicyHolderFieldGroupItem,
        AddlInterestFieldGroupItem,
    ],
    Field(..., discriminator="fieldName"),
]

ProtectPolicyFieldGroupItem = Annotated[
    Union[
        ProtectPolicyBuildingFieldGroupItem,
        NonPrimaryPolicyHolderFieldGroupItem,
        AddlInterestFieldGroupItem,
        ProtectiveDevicesFieldGroupItem,
    ],
    Field(..., discriminator="fieldName"),
]


# Main Classes


class Policy(BaseSocotraEntity):
    policyholderLocator: str
    productName: PRODUCT_NAMES

    policyStartTimestamp: datetime | None = None
    policyEndTimestamp: datetime | None = None
    exposures: Exposure | None = None
    autofill: list[Union[str, None]] = []
    currency: str | None = None
    finalize: bool = False

    @validator("policyStartTimestamp", "policyEndTimestamp", pre=True)
    def str_to_datetime(cls, v):
        if isinstance(v, str) and "T" in v:
            return datetime.fromisoformat(v)
        elif isinstance(v, (str, int)):
            return datetime.fromtimestamp(int(v) / 1000)
        return v


class DepositPolicy(Policy):
    paymentScheduleName: DEPOSIT_PAYMENT_OPTION
    fieldValues: DepositPolicyFieldValues
    fieldGroups: List[DepositPolicyFieldGroupItem]

    @property
    def id(self):
        return self.fieldValues.custom_policy_number


class ProtectPolicy(Policy):
    paymentScheduleName: PROTECT_PAYMENT_OPTION
    fieldValues: ProtectPolicyFieldValues
    fieldGroups: List[ProtectPolicyFieldGroupItem]

    @property
    def id(self):
        return self.fieldValues.custom_policy_number


class PolicyCancellation(BaseSocotraEntity):
    name: str
    effectiveTimestamp: datetime

    cancellationCategory: str | None = None
    cancellationComments: str | None = None
    issue: bool | None = False
    conflictCheck: Literal["block", "invalidate"] | None = None


# TODO union different schemas for different policies.


###### Update Policy Group fields ######
class UpdateAddlInterestFieldGroupItem(UpdateFieldGroupItem):
    fieldName: Literal["addl_interests"]
    fieldGroupLocator: str
    fieldValues: AddlInterest


class UpdateNonPrimaryPolicyHolderFieldGroupItem(UpdateFieldGroupItem):
    fieldName: Literal["non_primary_policy_holders"]
    fieldGroupLocator: str
    fieldValues: NonPrimaryPolicyHolder


class UpdatePolicyBuildingFieldGroupItem(UpdateFieldGroupItem):
    fieldName: Literal["building_details"]
    fieldGroupLocator: str
    fieldValues: BuidlingDetails


class UpdateProtectiveDevicesFieldGroupItem(UpdateFieldGroupItem):
    fieldName: Literal["protective_devices"]
    fieldGroupLocator: str
    fieldValues: ProtectiveDevices


UpdatePolicyUpdateFieldGroupItem = Annotated[
    Union[
        UpdateAddlInterestFieldGroupItem,
        UpdateNonPrimaryPolicyHolderFieldGroupItem,
        UpdatePolicyBuildingFieldGroupItem,
        UpdateProtectiveDevicesFieldGroupItem,
    ],
    Field(..., discriminator="fieldName"),
]

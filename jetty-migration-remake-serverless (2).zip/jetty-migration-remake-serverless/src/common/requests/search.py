import json
from typing import Any

from ..entities import Search
from .socotra_request import BaseSocotraRequest


class SearchRequest(BaseSocotraRequest):
    method = "POST"
    endpoint_start = "search"
    entity: Search

    def __init__(self, search_entity: Search) -> None:
        self.entity = search_entity

    @property
    def url(self) -> str:
        return f"/{self.endpoint_start}"

from typing import Any

from ..entities import AuxData
from .socotra_request import BaseSocotraRequest


class CreateAuxData(BaseSocotraRequest):
    endpoint_start = "auxData"
    method = "PUT"
    entity: AuxData
    master_policy_id: str

    def __init__(
        self,
        entity: AuxData,
        locator: str,
    ) -> None:
        super().__init__(entity, locator)
        self.entity = entity
        self.master_policy_id = locator

    @property
    def url(self) -> str:
        return f"/{self.endpoint_start}/{self.master_policy_id}"

    def __str__(self) -> str:
        return (
            f"/{self.endpoint_start}/{self.master_policy_id} - {self.master_policy_id}"
        )

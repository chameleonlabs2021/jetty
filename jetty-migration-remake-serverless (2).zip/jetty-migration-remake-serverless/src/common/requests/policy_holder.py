import json
from typing import Any

from ..entities import PolicyHolder
from .socotra_request import BaseSocotraRequest


class CreatePolicyHolder(BaseSocotraRequest):
    endpoint_start = "policyholder"
    endpoint_end = "create"
    entity: PolicyHolder

    def __init__(self, entity: PolicyHolder, locator: str = None) -> None:
        super().__init__(entity, locator)

    @property
    def url(self) -> str:
        return f"/{self.endpoint_start}/{self.endpoint_end}"

    def __str__(self) -> str:
        return f"/{self.endpoint_start}/{self.endpoint_end} - {self.entity.id}"

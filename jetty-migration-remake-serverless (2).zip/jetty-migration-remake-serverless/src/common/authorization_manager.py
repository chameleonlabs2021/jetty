import sys
from datetime import datetime
from time import time
from typing import Literal

from loguru import logger
from requests import HTTPError, Session

from .globals import *
from .requests.socotra_request import BaseSocotraRequest, BaseSocotraResponse


class SocotraAuthorizationManager:
    session: Session
    authorization_token: str = None  # token to be used in Authorization header
    expiration_time: int  # unix time converted to int
    auth_method: str

    def __init__(
        self,
        auth_method: Literal["socotra", "okta", "token"],
        url: str = SOCOTRA_URL,
        auth_token: str = None,
        expiration_time: datetime = None,
        hostname: str = SOCOTRA_HOSTNAME,
        username: str = SOCOTRA_USERNAME,
        password: str = SOCOTRA_PASSWORD,
        socotra_idp_url: str = SOCOTRA_IDP_URL,
        socotra_idp_realm: str = SOCOTRA_IDP_REALM,
        client_id: str = JETTY_SOCOTRA_CLIENT_ID,
        client_secret: str = JETTY_SOCOTRA_CLIENT_SECRET,
    ):
        self.url = url
        self.auth_method = auth_method
        match auth_method:
            case "socotra":
                self.hostname = hostname
                self.username = username
                self.password = password
            case "token":
                self.authorization_token = auth_token
                self.expiration_time = (
                    expiration_time
                    if isinstance(expiration_time, int)
                    else int(expiration_time.timestamp())
                )
            case "okta":
                self.socotra_idp_url = socotra_idp_url
                self.socotra_idp_realm = socotra_idp_realm
                self.client_id = client_id
                self.client_secret = client_secret

    @property
    def current_unix_time(self):
        return time()

    def request(
        self, request: BaseSocotraRequest = None, *args, **kwargs
    ) -> BaseSocotraResponse:
        if request:
            method, url, json = (
                request.method,
                f"{self.url}{request.url}",
                request.json(),
            )
            response = self.session.request(
                method=method, url=url, json=json, *args, **kwargs
            )
        else:
            response = self.session.request(*args, **kwargs)

        return BaseSocotraResponse(request=request, response=response)

    def __enter__(self):
        self.session = Session()
        try:
            if self.authorization_token:
                if self.expiration_time < (self.current_unix_time - 60):
                    logger.info("Token Expired. Renew it")
                    # (
                    #     self.authorization_token,
                    #     self.expiration_time,
                    # ) = self.__set_auth_credentials()
            else:
                (
                    self.authorization_token,
                    self.expiration_time,
                ) = self.__set_auth_credentials()

            self.session.headers.update(
                {
                    "Authorization": f"Bearer {self.authorization_token}",
                    "Content-Type": "application/json",
                }
            )
        except HTTPError as e:
            logger.error(
                f"Can not authenticate to Socotra using {self.auth_method}: {e}"
            )
        else:
            return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.session.close()

    def __authenticate_socotra(self) -> None:
        response = self.session.post(
            url=f"{self.url}/account/authenticate",
            json={
                "username": self.username,
                "password": self.password,
                "hostName": self.hostname,
            },
        )
        response.raise_for_status()
        return response

    def __authenticate_idp(self) -> None:
        response = self.session.post(
            url=f"{self.socotra_idp_url}/auth/realms/{self.socotra_idp_realm}/protocol/openid-connect/token",
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data={
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "grant_type": "client_credentials",
            },
        )
        response.raise_for_status()
        return response

    def __set_auth_credentials(self) -> (str, int):
        try:
            match self.auth_method:
                case "socotra":
                    response = self.__authenticate_socotra()
                    return response.json()["authorizationToken"], int(
                        response.json()["expiresTimestamp"]
                    )
                case "okta":
                    response = self.__authenticate_idp()
                    return (
                        response.json()["access_token"],
                        self.current_unix_time + int(response.json()["expires_in"]),
                    )
                case "token":
                    # Can not do nothing here, since the previous auth method is unknown
                    pass

        except Exception as e:
            print(e)

    def validate_token(self) -> bool:
        try:
            response = self.session.post(
                url=f"{self.url}/v1/ping/authorized",
            )
            response.raise_for_status()
            return True
        except Exception as e:
            print(e)
            return False

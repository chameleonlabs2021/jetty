import json
from datetime import datetime
from enum import Enum
from http import HTTPStatus

from pydantic import BaseModel, model_validator

from src.common.requests import BaseSocotraResponse


class InputObject(BaseModel):
    custom_member_id: str
    custom_policy_numbers: list[str]
    timestamp: datetime

    class Config:
        json_encoders = {
            datetime: lambda v: v.timestamp(),
        }


class OutputObject(BaseModel):
    socotra_token: str
    socotra_token_expiration: datetime | None = None

    additional: dict | None = None

    class Config:
        json_encoders = {
            datetime: lambda v: v.timestamp(),
        }

    def model_dump_dict(
        self,
        *args,
        **kwargs,
    ) -> str:
        return json.loads(
            super().model_dump_json(
                exclude_none=True,
                *args,
                **kwargs,
            )
        )

    @classmethod
    def from_response(cls, response: BaseSocotraResponse) -> "OutputObject":
        pass

    @model_validator(mode="before")
    @classmethod
    def validate_responses_b(csl, data):
        if isinstance(data, dict):
            data = {
                k: (HTTPStatus(v) if k.endswith("_status_code") else v)
                for k, v in data.items()
            }
        return data


class PHMigrationStatus(str, Enum):
    SUCCESS = "policyholder.migration.success"
    FAILED = "policyholder.migration.fail"


class MigrationResponse(BaseModel):
    status_code: HTTPStatus
    object: dict
    last_step: str | None = None


class PolicyMigrationStatus(str, Enum):
    SUCCESS = "policy.migration.success"
    FAILED = "policy.migration.fail"
    IN_PROGRESS = "policy.migration.in_progress"


class SingleResponseLocator(BaseModel):
    status_code: HTTPStatus
    locator: str | None = None


class DoubleResponseLocator(BaseModel):
    create_status_code: HTTPStatus
    issue_status_code: HTTPStatus | None = None
    locator: str | None = None


class PolicyLifecycleEventsStatuses(BaseModel):
    create_policy_status_code: HTTPStatus
    create_aux_status_code: HTTPStatus | None = None
    issue_policy_status_code: HTTPStatus | None = None
    issue_invoice_status_code: HTTPStatus | None = None
    payments: list[SingleResponseLocator] | None = None
    endorsements: list[DoubleResponseLocator] | None = None
    renewals: list[DoubleResponseLocator] | None = None
    cancellations: list[SingleResponseLocator] | None = None
    final_state: MigrationResponse | None = None


class TransferPolicy(BaseModel):
    locator: str
    custom_policy_number: str
    snowflake_input: dict
    statuses: PolicyLifecycleEventsStatuses
    policy_flow_end: datetime | None = None


class PolicyHolderResponse(BaseModel):
    custom_member_id: str
    locator: str | None
    status: PHMigrationStatus
    snowflake_input: dict
    response: MigrationResponse
    policies: list[str]
    kill_switch_enabled: bool

    def model_dump_dict(
        self,
        *args,
        **kwargs,
    ) -> str:
        return json.loads(
            super().model_dump_json(
                exclude_none=True,
                *args,
                **kwargs,
            )
        )

    @classmethod
    def from_response(
        cls,
        custom_member_id: str,
        response: BaseSocotraResponse,
        migration_status: PHMigrationStatus,
        snowflake_input: dict,
        policies: list[str] = [],
        kill_switch_enabled: bool = False,
    ) -> "PolicyHolderResponse":
        ph = PolicyHolderResponse(
            custom_member_id=custom_member_id,
            snowflake_input=snowflake_input,
            status=migration_status,
            locator=response.response.json()["locator"],
            response=MigrationResponse(
                status_code=response.status_code,
                object=response.response.json(),
            ),
            policies=policies,
            kill_switch_enabled=kill_switch_enabled,
        )
        return ph


class PolicyHolderOutputObject(OutputObject):
    policyholder_locator: str
    policy_locator: str


class PolicyOutputObject(OutputObject):
    policyholder_locator: str
    policy: TransferPolicy

    @classmethod
    def from_response(
        cls,
        response: BaseSocotraResponse,
        migration_status: PolicyMigrationStatus,
        policyholder_locator: str,
        snowflake_input: dict,
        custom_policy_number: str,
        socotra_token: str,
        socotra_token_expiration: datetime | None = None,
    ) -> "PolicyOutputObject":
        policy = TransferPolicy(
            custom_policy_number=custom_policy_number,
            locator=response.response.json()["locator"],
            snowflake_input=snowflake_input,
            migration_status=migration_status,
            statuses=PolicyLifecycleEventsStatuses(
                create_policy_status_code=response.status_code,
            ),
        )
        return PolicyOutputObject(
            socotra_token=socotra_token,
            socotra_token_expiration=socotra_token_expiration,
            policyholder_locator=policyholder_locator,
            policy=policy,
        )

    def add_auxdata(self, response: BaseSocotraResponse) -> None:
        self.policy.statuses.create_aux_status_code = response.status_code
        self.policy.statuses.final_state = MigrationResponse(
            status_code=response.status_code,
            object={"response": response.response.text},
            last_step="create_auxdata",
        )

    def add_issue_policy(self, response: BaseSocotraResponse) -> None:
        self.policy.statuses.issue_policy_status_code = response.status_code
        self.policy.statuses.final_state = MigrationResponse(
            status_code=response.status_code,
            object={"response": response.response.text},
            last_step="issue_policy",
        )

    def add_fetch_invoices(self, response: BaseSocotraResponse) -> None:
        self.policy.statuses.issue_invoice_status_code = response.status_code
        self.policy.statuses.final_state = MigrationResponse(
            status_code=response.status_code,
            object={"response": response.response.text},
            last_step="fetch_invoices",
        )

    def add_single_payment(self, response: BaseSocotraResponse) -> None:
        self.policy.statuses.payments = []
        self.policy.statuses.payments.append(
            SingleResponseLocator(
                status_code=response.status_code,
                locator=response.response.json()["locator"],
            )
        )
        self.policy.statuses.final_state = MigrationResponse(
            status_code=response.status_code,
            object={"response": response.response.text},
            last_step="pay_invoice",
        )

    def add_endorsement(self, response: BaseSocotraResponse) -> int:
        self.policy.statuses.endorsements = []
        self.policy.statuses.endorsements.append(
            DoubleResponseLocator(
                create_status_code=response.status_code,
                locator=response.response.json()["locator"],
            )
        )
        self.policy.statuses.final_state = MigrationResponse(
            status_code=response.status_code,
            object={"response": response.response.text},
            last_step="create_endorsement",
        )

        return len(self.policy.statuses.endorsements) - 1

    def add_issue_endorsement(
        self, endorsement_idx: int, response: BaseSocotraResponse
    ) -> None:
        self.policy.statuses.endorsements[
            endorsement_idx
        ].issue_status_code = response.status_code
        self.policy.statuses.final_state = MigrationResponse(
            status_code=response.status_code,
            object={"response": response.response.text},
            last_step="issue_endorsement",
        )

    def add_renewal(self, response: BaseSocotraResponse) -> int:
        self.policy.statuses.renewals = []
        self.policy.statuses.renewals.append(
            DoubleResponseLocator(
                create_status_code=response.status_code,
                locator=response.response.json()["locator"],
            )
        )
        self.policy.statuses.final_state = MigrationResponse(
            status_code=response.status_code,
            object={"response": response.response.text},
            last_step="create_renewal",
        )

        return len(self.policy.statuses.renewals) - 1

    def add_issue_renewal(
        self, renewal_idx: int, response: BaseSocotraResponse
    ) -> None:
        self.policy.statuses.renewals[
            renewal_idx
        ].issue_status_code = response.status_code
        self.policy.statuses.final_state = MigrationResponse(
            status_code=response.status_code,
            object={"response": response.response.text},
            last_step="issue_renewal",
        )

    def add_cancellation(self, response: BaseSocotraResponse) -> None:
        self.policy.statuses.cancellations = []
        self.policy.statuses.cancellations.append(
            SingleResponseLocator(
                status_code=response.status_code,
                locator=response.response.json()["locator"],
            )
        )

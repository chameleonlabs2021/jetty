from .base_entity import BaseModel, BaseSocotraEntity


class InvoiceFieldValues(BaseModel):
    stripe_payment_id: str
    stripe_source_status: str


class Invoice(BaseSocotraEntity):
    fieldValues: InvoiceFieldValues

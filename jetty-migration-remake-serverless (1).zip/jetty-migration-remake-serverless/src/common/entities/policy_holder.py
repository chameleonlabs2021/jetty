from datetime import date, datetime
from typing import Literal

from pydantic import validator

from .base_entity import BaseSocotraEntity


class PolicyHolder(BaseSocotraEntity):
    first_name: str
    last_name: str
    email: str
    phone_number: str | None = None
    date_of_birth: date | None = None
    custom_member_id: str

    ofac_outcome: Literal["approved", "step Up"] | None = None
    ofac_reason: str | None = None
    ofac_date: int | None = None

    # stripe ids
    stripe_publishable_key: str | None = None
    stripe_customer_id: str | None = None
    stripe_source_id: str | None = None
    # will be adjusted
    stripe_customer_id_2: str | None = None
    stripe_customer_id_3: str | None = None
    stripe_customer_id_4: str | None = None
    stripe_customer_id_5: str | None = None

    @property
    def id(self):
        return self.custom_member_id

    @validator("ofac_date", pre=True)
    def validated_unix_date(cls, v):
        try:
            date = datetime.fromtimestamp(v)
        except Exception as e:
            return None
        else:
            return v

from .aux_data import AuxData
from .base_entity import BaseSocotraEntity, Search
from .endorsement import Endorsement
from .invoice import Invoice
from .policy import DepositPolicy, PolicyCancellation, ProtectPolicy
from .policy_holder import PolicyHolder
from .renewal import Renewal

ENTITY_TYPES = [
    "PolicyHolder",
    "DepositPolicy",
    "ProtectPolicy",
    "AuxData",
    "Endorsement",
    "Renewal",
]

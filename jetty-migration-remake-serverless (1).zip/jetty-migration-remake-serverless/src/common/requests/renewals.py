from ..entities import Renewal
from .socotra_request import BaseSocotraRequest


class CreateRenewal(BaseSocotraRequest):
    endpoint_start = "policies"
    endpoint_end = "renewals"
    method = "POST"
    entity: Renewal
    policy_locator: str

    def __init__(self, locator: str, entity: Renewal) -> None:
        self.policy_locator = locator
        self.entity = entity

    @property
    def url(self) -> str:
        return f"/{self.endpoint_start}/{self.policy_locator}/{self.endpoint_end}"

    def __str__(self) -> str:
        return f"/{self.endpoint_start}/{self.policy_locator}/{self.endpoint_end} - {self.policy_locator}"


class IssueRenewal(BaseSocotraRequest):
    endpoint_start = "renewals"
    endpoint_end = "issue"
    method = "PATCH"
    entity = None
    renewal_locator: str

    def __init__(
        self,
        locator: str,
        entity=None,
    ) -> None:
        super().__init__()
        self.renewal_locator = locator

    @property
    def url(self) -> str:
        return f"/{self.endpoint_start}/{self.renewal_locator}/{self.endpoint_end}"

    def __str__(self) -> str:
        return f"/{self.endpoint_start}/{self.renewal_locator}/{self.endpoint_end} - {self.renewal_locator}"

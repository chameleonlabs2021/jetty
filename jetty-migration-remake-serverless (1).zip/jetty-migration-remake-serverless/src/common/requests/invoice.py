from ..entities import Invoice
from .socotra_request import BaseSocotraRequest


class PayInvoice(BaseSocotraRequest):
    endpoint_start = "invoice"
    endpoint_end = "pay"
    method = "POST"
    entity: Invoice = None
    invoice_locator: str

    def __init__(self, locator: str, entity=None) -> None:
        super().__init__()
        self.entity = entity
        self.invoice_locator = locator

    @property
    def url(self) -> str:
        return f"/{self.endpoint_start}/{self.invoice_locator}/{self.endpoint_end}"

    def __str__(self) -> str:
        return f"/{self.endpoint_start}/{self.invoice_locator}/{self.endpoint_end} - {self.invoice_locator}"

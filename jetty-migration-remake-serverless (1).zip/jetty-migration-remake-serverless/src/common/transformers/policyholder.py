from datetime import datetime

import pandas as pd

from src.common.entities.policy_holder import PolicyHolder


def resolve_date(date_str):
    try:
        date = datetime.strptime(date_str, "%Y-%m-%d").date()
    except Exception as e:
        date = datetime.fromtimestamp(965127141).date()
    finally:
        return date


def resolve_stripe(stripe_str):
    if pd.notna(stripe_str):
        stripe_list = stripe_str.split("|")
        return stripe_list[0], stripe_list[1]
    else:
        return None, None


resolve_scid = lambda x: x.split(",")[0] if pd.notna(x) else None
resolve_email = lambda x: x if pd.notna(x) else ""


def create_policy_holder(row):
    first_name, last_name = row["NAME"].split(" ")[0], row["NAME"].split(" ")[1]
    strip_publishable_key, stripe_source_id = resolve_stripe(
        row["STRIPE_PUBLISHABLE_KEY_AND_PAYMENT_METHODS"]
    )
    return PolicyHolder(
        first_name=first_name,
        last_name=last_name,
        email=resolve_email(row["EMAIL"]),
        date_of_birth=resolve_date(row["DOB"]),
        custom_member_id=row["MEMBER_ID"],
        strip_publishable_key=strip_publishable_key,
        stripe_source_id=stripe_source_id,
        stripe_customer_id=resolve_scid(row["STRIPE_CUSTOMER_PROFILE_IDS"]),
    )

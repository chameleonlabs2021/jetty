import json

from src.common.authorization_manager import SocotraAuthorizationManager
from src.common.entities import PolicyCancellation
from src.common.requests import CreatePolicyCancelation, IssuePolicyCancelation
from src.common.transfer_object import PolicyMigrationStatus, PolicyOutputObject


def handle(event, context):
    """
    AWS lambda function to create and issue Policy Cancelation in Socotra.
    """
    # TODO
    # Retrieve Renewal(s) From SF
    # Serialize
    # Send Create Request to Socotra
    # Send Issue Request to Socotra
    # Log Message

    dev = False
    try:
        if isinstance(event, dict) and "body" in event.keys():
            dev = True
            input = PolicyOutputObject.model_validate(eval(event["body"]))
        else:
            input = PolicyOutputObject.model_validate(event)
    except Exception as e:
        print(e)
        # TODO: finish the flow
        return {"statusCode": 400, "output": "No final response"}

    output = input.model_copy(deep=True)

    ph2_cancellation = PolicyCancellation.model_validate_json(
        """
    {
        "name": "moveout",
        "effectiveTimestamp": 1788889350000,
        "cancellationCategory": "Claim Eligible",
        "issue": false
    }
    """
    )
    with SocotraAuthorizationManager(
        auth_method="token",
        auth_token=input.socotra_token,
        expiration_time=input.socotra_token_expiration,
    ) as socotra:
        create_cancellation = CreatePolicyCancelation(
            locator=input.policy.locator, entity=ph2_cancellation
        )
        create_cancellation_response = socotra.request(request=create_cancellation)

        if str(create_cancellation_response.status_code).startswith("2"):
            output.add_cancellation(create_cancellation_response)
        else:
            migration_status = PolicyMigrationStatus.FAILED
            return {
                "statusCode": create_cancellation_response.status_code,
                "body" if dev else "output": create_cancellation_response.response.text,
            }

    return {
        "statusCode": create_cancellation_response.status_code,
        "body" if dev else "output": json.loads(output.model_dump_json()),
    }

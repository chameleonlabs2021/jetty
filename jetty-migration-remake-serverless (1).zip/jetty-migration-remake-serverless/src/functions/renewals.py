import json
from datetime import datetime

from src.common.authorization_manager import SocotraAuthorizationManager
from src.common.entities import Renewal
from src.common.requests import CreateRenewal, IssueRenewal
from src.common.transfer_object import PolicyMigrationStatus, PolicyOutputObject


def handle(event, context):
    """
    AWS lambda function to create and issue a renewal in Socotra.
    """
    # TODO
    # Retrieve Renewal(s) From SF
    # Serialize
    # Send Create Request to Socotra
    # Send Issue Request to Socotra
    # Log Message

    dev = False
    try:
        if isinstance(event, dict) and "body" in event.keys():
            dev = True
            input = PolicyOutputObject.model_validate(eval(event["body"]))
        else:
            input = PolicyOutputObject.model_validate(event)
    except Exception as e:
        print(e)
        # TODO: finish the flow
        return {"statusCode": 400, "output": "No final response"}

    renewal = Renewal.model_validate(
        {"renewalEndTimestamp": datetime(2030, 11, 1, 1, 39, 6, 123000)}
    )

    output = input.model_copy(deep=True)

    with SocotraAuthorizationManager(
        auth_method="token",
        auth_token=input.socotra_token,
        expiration_time=input.socotra_token_expiration,
    ) as socotra:
        create_renewal = CreateRenewal(locator=input.policy.locator, entity=renewal)
        create_renewal_response = socotra.request(request=create_renewal)

        if str(create_renewal_response.status_code).startswith("2"):
            renewal_locator = create_renewal_response.response.json()["locator"]
            idx = output.add_renewal(create_renewal_response)
        else:
            migration_status = PolicyMigrationStatus.FAILED
            return {
                "statusCode": create_renewal_response.status_code,
                "body" if dev else "output": create_renewal_response.response.text,
            }

        issue_renewal = IssueRenewal(locator=renewal_locator)
        issue_renewal_response = socotra.request(request=issue_renewal)

        if str(create_renewal_response.status_code).startswith("2"):
            output.add_issue_renewal(renewal_idx=idx, response=create_renewal_response)
        else:
            migration_status = PolicyMigrationStatus.FAILED
            return {
                "statusCode": create_renewal_response.status_code,
                "body" if dev else "output": create_renewal_response.response.text,
            }

    return {
        "statusCode": issue_renewal_response.status_code,
        "body" if dev else "output": json.loads(output.model_dump_json()),
    }

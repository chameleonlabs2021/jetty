import json
from loguru import logger

from src.common.authorization_manager import SocotraAuthorizationManager
from src.common.entities import PolicyHolder, Search
from src.common.globals import (
    JETTY_SOCOTRA_CLIENT_ID,
    JETTY_SOCOTRA_CLIENT_SECRET,
    SOCOTRA_IDP_REALM,
    SOCOTRA_IDP_URL,
    SOCOTRA_URL,
)
from src.common.requests import CreatePolicyHolder, SearchRequest
from src.common.transfer_object import (
    InputObject,
    PHMigrationStatus,
    PolicyHolderOutputObject,
    PolicyHolderResponse,
)


def handle(event, context):
    """
    AWS lambda function to create a policyholder in Socotra

    input: PolicyHolder ID
    output: HTTP Response status
    """

    # Resolve the Input
    dev = False
    try:
        if isinstance(event, dict) and "body" in event.keys():
            dev = True
            input = InputObject.model_validate(eval(event["body"]))
        else:
            input = InputObject.model_validate(event)
    except Exception as e:
        print(e)
        # TODO: finish the flow
        return {"statusCode": 400, "output": "No final response"}

    # Retrieve PH from SF
    # Serialize PH
    data_from_sf = {
        "first_name": "Malachi",
        "last_name": "Greenholt",
        "email": "Jensen_Sanford@hotmail.com",
        "phone_number": "828-709-6734",
        "date_of_birth": "2000-01-01",
        "custom_member_id": "AA2222",
        "ofac_outcome": "approved",
        "ofac_reason": "Try to generate the AI array, maybe it will override the virtual card!",
        "ofac_date": 1686866400,
        "stripe_publishable_key": "20a682eb-f090-46b4-bacf-1748946f9eaa",
        "stripe_customer_id": "b4dede5a-09b1-4b27-b4c4-a7ac50f60a2f",
        "stripe_source_id": "99799d30-bb42-4e03-b9de-756a713fbfa9",
    }
    policy_holder = PolicyHolder.model_validate(data_from_sf)

    # Send a Request to Socotra
    with SocotraAuthorizationManager(
        auth_method="okta",
        url=SOCOTRA_URL,
        socotra_idp_url=SOCOTRA_IDP_URL,
        socotra_idp_realm=SOCOTRA_IDP_REALM,
        client_id=JETTY_SOCOTRA_CLIENT_ID,
        client_secret=JETTY_SOCOTRA_CLIENT_SECRET,
    ) as socotra:
        # Save Toke and Expiration Time
        socotra_token_expiration = socotra.expiration_time
        socotra_token = socotra.authorization_token

        # Check if PolicyHolder already exists in Socotra
        request = SearchRequest(
            search_entity=Search(searchString=input.custom_member_id)
        )
        search_response = socotra.request(request)
        ph_already_created = False

        if search_response.status_code == 200 and (
            res_dict := search_response.response.json()["results"]
        ):
            existing_ph = [_ for _ in res_dict if _["type"] == "policyholder"]
            if existing_ph:
                policyholder_locator = existing_ph[0]["policyholderLocator"]
                ph_already_created = True
                migration_status = PHMigrationStatus.SUCCESS
                # Submit Key Pair
            else:
                # found some results but no policyholder
                print(res_dict)
                ph_already_created = False

        if not ph_already_created:
            create_ph = CreatePolicyHolder(entity=policy_holder)
            socotra_response = socotra.request(create_ph)
            # Handle the Response
            if socotra_response.status_code == 200:
                migration_status = PHMigrationStatus.SUCCESS
            else:
                migration_status = PHMigrationStatus.FAILED

            # Log Message
            # Submit Key Pair
            response = PolicyHolderResponse.from_response(
                custom_member_id=input.custom_member_id,
                response=socotra_response,
                migration_status=migration_status,
                snowflake_input=policy_holder.model_dump(),
            )
            policyholder_locator = response.locator

    outputs = [
        PolicyHolderOutputObject(
            policyholder_locator=policyholder_locator,
            policy_locator=policy_locator,
            socotra_token=socotra_token,
            socotra_token_expiration=socotra_token_expiration,
        )
        for policy_locator in input.custom_policy_numbers
    ]

    final_response = {
        "detail-type": migration_status,
        "detail": {
            "policyholder": response.model_dump_dict(),
        },
    }

    if dev:
        response = {
            "statusCode": socotra_response.status_code,
            "body": "{body}".format(body = json.dumps({
                "response": final_response,
                "output": [output.model_dump_dict() for output in outputs],
            })),
        }
        
        logger.debug(response)
        return response

    return {
        "statusCode": socotra_response.status_code,
        "response": final_response,
        "output": [output.model_dump_dict() for output in outputs],
    }

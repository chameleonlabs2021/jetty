import os

from src.common.authorization_manager import SocotraAuthorizationManager
from src.common.globals import (
    SOCOTRA_HOSTNAME,
    SOCOTRA_PASSWORD,
    SOCOTRA_URL,
    SOCOTRA_USERNAME,
)


def start_migration(event, context):
    """
    Start the migration process
    """

    # TODO
    # Checks Socotra and Snowflake
    # Check KillSwitch
    # Socotra AUTH

    print("Starting migration process...")
    print(
        os.getenv("SOCOTRA_URL") if os.getenv("SOCOTRA_URL") else "SOCOTRA_URL is None"
    )

    with SocotraAuthorizationManager(
        url=SOCOTRA_URL,
        hostname=SOCOTRA_HOSTNAME,
        username=SOCOTRA_USERNAME,
        password=SOCOTRA_PASSWORD,
    ) as socotra:
        print("socotra authorized")

    return {"statusCode": 200}

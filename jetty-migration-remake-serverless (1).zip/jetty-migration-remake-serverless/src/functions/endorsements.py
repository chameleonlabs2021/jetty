import json

from src.common.authorization_manager import SocotraAuthorizationManager
from src.common.entities import Endorsement
from src.common.requests import CreateEndorsement, IssueEndorsement
from src.common.transfer_object import PolicyMigrationStatus, PolicyOutputObject


def handle(event, context):
    """
    AWS lambda function to create and issue an endorsement in Socotra.
    """
    # TODO
    # Retrieve Endorsement From SF
    # Serialize
    # Handle multiple endorsements
    # Send Create Request to Socotra
    # Send Issue Request to Socotra
    # Log Message

    dev = False
    try:
        if isinstance(event, dict) and "body" in event.keys():
            dev = True
            input = PolicyOutputObject.model_validate(eval(event["body"]))
        else:
            input = PolicyOutputObject.model_validate(event)
    except Exception as e:
        print(e)
        # TODO: finish the flow
        return {"statusCode": 400, "output": "No final response"}

    output = input.model_copy(deep=True)

    ph1_endorsement_1 = Endorsement.model_validate_json(
        """
    {
        "endorsementName": "endorsement.with.repricing",
        "addFieldGroups": [
            {
                "fieldName": "non_primary_policy_holders",
                "fieldValues": {
                    "non_primary_name": "Witting",
                    "non_primary_email": "George.Ruecker16@hotmail.com",
                    "non_primary_phone": "660-412-5960",
                    "non_primary_dob": "2000-01-01",
                    "non_primary_custom_member_id": "AA4590",
                    "non_primary_relationship": "spouse_named_insured"
                }
            }
        ],
        "updateFieldGroups": [
            {
                "fieldGroupLocator": "58ab06d5-c03c-4864-8de5-d511c15c7f7f",
                "fieldName": "building_details",
                "fieldValues": {
                    "address_line_1": "42561 Lonny Isle",
                    "address_line_2": "51042 Carroll Estates",
                    "address_city": "Erie",
                    "address_state": "NY",
                    "address_zip": "10004",
                    "address_county": "New York County",
                    "building_id": "k",
                    "sfdc_property_id_at_purchase": "f",
                    "iso_territory_code": "5",
                    "iso_protection_class": "7"
                }
            }
        ],
        "fieldValues": {
            "rater_source": "AA4590",
            "rater_id": "AA4590",
            "custom_policy_number": "AA2221",
            "auto_renewal_status": "renew"
        }
    }
    """
    )
    ph1_endorsement_1.updateFieldGroups[0].fieldGroupLocator = input.additional[
        "building_locator"
    ]

    with SocotraAuthorizationManager(
        auth_method="token",
        auth_token=input.socotra_token,
        expiration_time=input.socotra_token_expiration,
    ) as socotra:
        create_endorsement = CreateEndorsement(
            entity=ph1_endorsement_1, locator=input.policy.locator
        )
        create_endorsement_resp = socotra.request(request=create_endorsement)

        if str(create_endorsement_resp.status_code).startswith("2"):
            endorsement_idx = output.add_endorsement(create_endorsement_resp)
            endorsement_locator = create_endorsement_resp.response.json()["locator"]
        else:
            migration_status = PolicyMigrationStatus.FAILED
            return {
                "statusCode": create_endorsement_resp.status_code,
                "output": create_endorsement_resp.response.text,
            }

        issue_endorsement = IssueEndorsement(locator=endorsement_locator)
        issue_endorsement_resp = socotra.request(request=issue_endorsement)

        if str(issue_endorsement_resp.status_code).startswith("2"):
            output.add_issue_endorsement(endorsement_idx, create_endorsement_resp)
            endorsement_locator = create_endorsement_resp.response.json()["locator"]
        else:
            migration_status = PolicyMigrationStatus.FAILED
            return {
                "statusCode": create_endorsement_resp.status_code,
                "output": create_endorsement_resp.response.text,
            }

    if dev:
        return json.dumps(
            {
                "statusCode": issue_endorsement_resp.status_code,
                "output": json.loads(output.model_dump_json()),
            }
        )

    return {
        "statusCode": issue_endorsement_resp.status_code,
        "output": json.loads(output.model_dump_json()),
    }

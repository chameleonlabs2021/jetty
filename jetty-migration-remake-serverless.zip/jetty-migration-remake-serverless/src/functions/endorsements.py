import json

from src.common.entities import Endorsement
from src.common.requests import CreateEndorsement, IssueEndorsement


def handle(event, context):
    """
    AWS lambda function to create and issue an endorsement in Socotra.
    """
    # TODO
    # Retrieve Endorsement From SF
    # Serialize
    # Send Create Request to Socotra
    # Send Issue Request to Socotra
    # Log Message

    return {"statusCode": 200, "body": "Endorsement created and issued"}

import json

from src.common.entities import PolicyCancellation
from src.common.requests import CreatePolicyCancelation, IssuePolicyCancelation


def handle(event, context):
    """
    AWS lambda function to create and issue Policy Cancelation in Socotra.
    """
    # TODO
    # Retrieve Renewal(s) From SF
    # Serialize
    # Send Create Request to Socotra
    # Send Issue Request to Socotra
    # Log Message

    return {"statusCode": 200, "body": "Cancelation created and issued"}

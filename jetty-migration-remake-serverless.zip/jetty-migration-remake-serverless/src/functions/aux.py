import json

from src.common.entities import AuxData
from src.common.requests import CreateAuxData


def handle(event, context):
    """
    AWS lambda function to create an AUX data in Socotra.
    """
    # TODO
    # Retrieve AUX From SF
    # Serialize
    # Send Create Request to Socotra
    # Send Issue Request to Socotra
    # Log Message

    return {"statusCode": 200, "body": "AUX created and issued"}

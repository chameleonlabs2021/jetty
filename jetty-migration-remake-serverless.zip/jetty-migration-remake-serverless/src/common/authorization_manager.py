from time import time
from typing import Literal

from loguru import logger
from requests import Session

from .globals import *
from .requests.socotra_request import BaseSocotraRequest, BaseSocotraResponse


class SocotraAuthorizationManager:
    session: Session
    authorization_token: str = None  # token to be used in Authorization header
    expiration_time: int  # unix time converted to int
    auth_method: str

    def __init__(
        self,
        auth_method: Literal["socotra", "okta", "token"],
        url: str = SOCOTRA_URL,
        auth_token: str = None,
        expiration_time: int = None,
        hostname: str = SOCOTRA_HOSTNAME,
        username: str = SOCOTRA_USERNAME,
        password: str = SOCOTRA_PASSWORD,
        socotra_idp_url: str = SOCOTRA_IDP_URL,
        socotra_idp_realm: str = SOCOTRA_IDP_REALM,
        client_id: str = JETTY_SOCOTRA_CLIENT_ID,
        client_secret: str = JETTY_SOCOTRA_CLIENT_SECRET,
    ):
        self.url = url
        self.auth_method = auth_method
        match auth_method:
            case "socotra":
                self.hostname = hostname
                self.username = username
                self.password = password
            case "token":
                self.authorization_token = auth_token
                self.expiration_time = expiration_time
            case "okta":
                self.socotra_idp_url = socotra_idp_url
                self.socotra_idp_realm = socotra_idp_realm
                self.client_id = client_id
                self.client_secret = client_secret

    @property
    def current_unix_time(self):
        return int(time())

    def request(
        self, request: BaseSocotraRequest = None, *args, **kwargs
    ) -> BaseSocotraResponse:
        if request:
            method, url, json = (
                request.method,
                f"{self.url}{request.url}",
                request.json(),
            )

            response = self.session.request(
                method=method, url=url, json=json, *args, **kwargs
            )
        else:
            response = self.session.request(*args, **kwargs)

        return BaseSocotraResponse(request=request, response=response)

    def renew_socotra_auth_credentials(self) -> None:
        if self.current_unix_time >= self.expiration_time:
            self.__set_auth_credentials()
            self.session.headers.update({"Authorization": self.authorization_token})
        else:
            pass

    def __enter__(self):
        self.session = Session()
        if self.authorization_token:
            self.session.headers.update({"Authorization": self.authorization_token})
        else:
            (
                self.authorization_token,
                self.expiration_time,
            ) = self.__set_auth_credentials()
            self.session.headers.update(
                {"Authorization": f"Bearer {self.authorization_token}"}
            )
        self.session.headers.update({"Content-Type": "application/json"})
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.session.close()

    def __authenticate_socotra(self) -> None:
        response = self.session.post(
            url=f"{self.url}/account/authenticate",
            json={
                "username": self.username,
                "password": self.password,
                "hostName": self.hostname,
            },
        )
        response.raise_for_status()
        return response

    def __authenticate_idp(self) -> None:
        response = self.session.post(
            url=f"{self.socotra_idp_url}/auth/realms/{self.socotra_idp_realm}/protocol/openid-connect/token",
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data={
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "grant_type": "client_credentials",
            },
        )
        response.raise_for_status()
        return response

    def __set_auth_credentials(self) -> (str, int):
        try:
            match self.auth_method:
                case "socotra":
                    response = self.__authenticate_socotra()
                    return response.json()["authorizationToken"], int(
                        response.json()["expiresTimestamp"]
                    )
                case "okta":
                    response = self.__authenticate_idp()
                    return (
                        response.json()["access_token"],
                        self.current_unix_time + int(response.json()["expires_in"]),
                    )

        except Exception as e:
            print(e)

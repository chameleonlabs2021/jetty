from datetime import datetime
from enum import Enum
from typing import Literal, Union

from .base_entity import *
from .policy import (
    DepositPolicyFieldGroupItem,
    GroupItemNames,
    ProtectPolicyFieldGroupItem,
    UpdatePolicyUpdateFieldGroupItem,
)

EndrosmentState = Literal["application", "quoted", "accepted", "issued"]
ConflictHandling = Literal["block", "invalidate"]


PolicyFieldGroupItem = Union[ProtectPolicyFieldGroupItem, DepositPolicyFieldGroupItem]


class Endorsement(BaseSocotraEntity):
    endorsementName: str

    state: EndrosmentState | None = None
    startTimestamp: datetime | None = None
    newPolicyEndTimestamp: datetime | None = None
    fieldValues: FieldValues | None = None

    addFieldGroups: list[PolicyFieldGroupItem] | None = None
    updateFieldGroups: list[
        UpdatePolicyUpdateFieldGroupItem
    ] | UpdatePolicyUpdateFieldGroupItem | None = None
    removeFieldGroups: str | None = None

    addExposures: list[Exposure] | Exposure | None = None
    updateExposures: list[UpdateExposure] | UpdateExposure | None = None
    endExposures: str | None = None

    autofill: list | None = None
    newPaymentScheduleName: str | None = None
    reprice: bool | None = None
    conflictHandling: ConflictHandling | None = None

    def set_update_locator(self, locator: str, group_item_name: GroupItemNames):
        if isinstance(self.updateFieldGroups, list):
            for _ in self.updateFieldGroups:
                if _.fieldName == group_item_name:
                    _.fieldGroupLocator = locator
        elif isinstance(self.updateFieldGroups, UpdatePolicyUpdateFieldGroupItem):
            self.updateFieldGroups.fieldGroupLocator = locator

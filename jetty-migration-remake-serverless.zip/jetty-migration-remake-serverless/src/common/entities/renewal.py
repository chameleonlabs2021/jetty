from datetime import datetime

from .base_entity import *


class Renewal(BaseSocotraEntity):
    renewalEndTimestamp: datetime

    fieldValues: FieldValues | None = None

    addFieldGroups: list[FieldGroupItemBase] | FieldGroupItemBase | None = None
    updateFieldGroups: list[UpdateFieldGroupItem] | UpdateFieldGroupItem | None = None
    removeFieldGroups: str | None = None

    addExposures: list[Exposure] | Exposure | None = None
    updateExposures: list[UpdateExposure] | UpdateExposure | None = None
    endExposures: str | None = None

    autofill: list | None = None
    newPaymentScheduleName: str | None = None

    # def set_update_locator(self, locator: str, group_item_name: GroupItemNames):
    #     if isinstance(self.updateFieldGroups, list):
    #         for _ in self.updateFieldGroups:
    #             if _.fieldName == group_item_name:
    #                 _.fieldGroupLocator = locator
    #     elif isinstance(self.updateFieldGroups, UpdatePolicyUpdateFieldGroupItem):
    #         self.updateFieldGroups.fieldGroupLocator = locator

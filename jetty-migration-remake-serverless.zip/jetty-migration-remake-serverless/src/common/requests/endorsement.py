from ..entities import Endorsement
from .socotra_request import BaseSocotraRequest


class CreateEndorsement(BaseSocotraRequest):
    endpoint_start = "policies"
    endpoint_end = "endorsements"
    method = "POST"
    entity: Endorsement
    policy_locator: str

    def __init__(self, entity: Endorsement, locator: str) -> None:
        self.policy_locator = locator
        self.entity = entity

    @property
    def url(self) -> str:
        return f"/{self.endpoint_start}/{self.policy_locator}/{self.endpoint_end}"

    def __str__(self) -> str:
        return f"/{self.endpoint_start}/{self.policy_locator}/{self.endpoint_end} - {self.policy_locator}"


class IssueEndorsement(BaseSocotraRequest):
    endpoint_start = "endorsements"
    endpoint_end = "issue"
    method = "PATCH"
    entity = None
    endorsement_locator: str

    def __init__(self, locator: str, entity=None) -> None:
        super().__init__()
        self.endorsement_locator = locator

    @property
    def url(self) -> str:
        return f"/{self.endpoint_start}/{self.endorsement_locator}/{self.endpoint_end}"

    def __str__(self) -> str:
        return f"/{self.endpoint_start}/{self.endorsement_locator}/{self.endpoint_end} - {self.endorsement_locator}"

from .aux_data import CreateAuxData
from .endorsement import CreateEndorsement, IssueEndorsement
from .invoice import PayInvoice
from .policy import (
    CreatePolicy,
    CreatePolicyCancelation,
    FetchPolicyInvoices,
    IssuePolicy,
    IssuePolicyCancelation,
)
from .policy_holder import CreatePolicyHolder
from .renewals import CreateRenewal, IssueRenewal
from .search import SearchRequest
from .socotra_request import BaseSocotraRequest, BaseSocotraResponse

DefaultSocotraRequestsSequence = [
    CreatePolicyHolder,
    CreatePolicy,
    CreateAuxData,
    IssuePolicy,
    FetchPolicyInvoices,
    PayInvoice,
    CreateEndorsement,
    IssueEndorsement,
    CreateRenewal,
    IssueRenewal,
    CreatePolicyCancelation,
    IssuePolicyCancelation,
]

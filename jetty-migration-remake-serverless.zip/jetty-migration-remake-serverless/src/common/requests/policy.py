import json
from typing import Union

from ..entities import (
    BaseSocotraEntity,
    DepositPolicy,
    PolicyCancellation,
    ProtectPolicy,
)
from .socotra_request import BaseSocotraRequest

Policy = Union[DepositPolicy, ProtectPolicy]


class CreatePolicy(BaseSocotraRequest):
    endpoint_start = "policy"
    method = "POST"
    entity: Policy

    def __init__(self, entity: Policy, locator: str) -> None:
        super().__init__(entity=entity)
        self.entity.policyholderLocator = locator

    @property
    def url(self) -> str:
        return f"/{self.endpoint_start}"

    def __str__(self) -> str:
        return f"/{self.endpoint_start} - {self.entity.id}"


class IssuePolicy(BaseSocotraRequest):
    endpoint_start = "policy"
    endpoint_end = "issue"
    method = "POST"
    entity = None
    policy_id: str

    def __init__(
        self,
        locator: str,
        entity=None,
    ) -> None:
        super().__init__(locator=locator, entity=entity)
        self.policy_id = locator

    @property
    def url(self) -> str:
        return f"/{self.endpoint_start}/{self.policy_id}/{self.endpoint_end}"

    def __str__(self) -> str:
        return f"/{self.endpoint_start}/{self.policy_id}/{self.endpoint_end} - {self.policy_id}"


class FetchPolicyInvoices(BaseSocotraRequest):
    endpoint_start = "policy"
    endpoint_end = "checkInvoices"
    method = "GET"
    entity = None
    policy_id: str

    def __init__(self, locator: str, entity=None) -> None:
        super().__init__(locator=locator)
        self.policy_id = locator

    @property
    def url(self) -> str:
        return f"/{self.endpoint_start}/{self.policy_id}/{self.endpoint_end}"

    def __str__(self) -> str:
        return f"/{self.endpoint_start}/{self.policy_id}/{self.endpoint_end} - {self.policy_id}"


class CancelPolicy(BaseSocotraRequest):
    endpoint_start = "policy"
    endpoint_end = "cancel"
    method = "POST"
    policy_id: str

    def __init__(self, locator: str, entity=None) -> None:
        super().__init__(locator=locator, entity=entity)
        self.policy_id = locator


class CreatePolicyCancelation(BaseSocotraRequest):
    # TODO: Handle refunds are not creating after the policy is cancelled (later)
    endpoint_start = "policies"
    endpoint_end = "cancellations"
    method = "POST"
    policy_id: str

    def __init__(self, entity: PolicyCancellation, locator: str = None) -> None:
        super().__init__(locator=locator, entity=entity)
        self.entity = entity
        self.policy_id = locator

    @property
    def url(self) -> str:
        return f"/{self.endpoint_start}/{self.policy_id}/{self.endpoint_end}"

    def __str__(self) -> str:
        return f"/{self.endpoint_start}/{self.policy_id}/{self.endpoint_end} - {self.policy_id}"


class IssuePolicyCancelation(BaseSocotraRequest):
    endpoint_start = "cancellations"
    endpoint_end = "issue"
    method = "PATCH"
    cancellation_id: str

    def __init__(self, locator: str, entity=None) -> None:
        self.cancellation_id = locator

    @property
    def url(self) -> str:
        return f"/{self.endpoint_start}/{self.cancellation_id}/{self.endpoint_end}"

    def __str__(self) -> str:
        return f"/{self.endpoint_start}/{self.cancellation_id}/{self.endpoint_end} - {self.cancellation_id}"

import json
from abc import ABC, abstractmethod
from typing import Literal, Optional, Union

from requests import Response

from ..entities import BaseSocotraEntity
from ..globals import SOCOTRA_URL


class BaseSocotraRequest:
    endpoint: str
    method: Literal["POST", "GET", "PUT", "PATCH", "DELETE"] = "POST"
    entity: BaseSocotraEntity
    locator: str

    def __init__(self, entity: BaseSocotraEntity = None, locator: str = None) -> None:
        self.entity = entity
        self.locator = locator

    def json(self, *args, **kwargs):
        if self.entity:
            entity_json = self.entity.model_dump_json(
                # exclude={"retrieved_from_brighcore", "uploaded_to_socotra"},
                exclude_none=True,
                *args,
                **kwargs,
            )
            if self.entity.class_name == "PolicyHolder":
                entity_json = f'{{"values": {entity_json}, "completed": true  }}'
            return json.loads(entity_json)
        else:
            return {}

    @property
    @abstractmethod
    def url(self) -> str:
        ...


class BaseSocotraResponse:
    request: BaseSocotraRequest
    response: dict
    status_code: int

    def __init__(
        self,
        request: BaseSocotraRequest,
        response: Response,
    ) -> None:
        self.request = request
        self.response = response
        self.status_code = response.status_code

    @property
    def request_name(self) -> str:
        return str(self.request.__class__.__name__)

    # @property
    # def generated_response_locators(self) -> list[str]:
    #     if (
    #         hasattr(self.request, "enpoint_end")
    #         and self.request.enpoint_end == "checkInvoices"
    #     ):
    #         return [
    #             invoice["invoice"]["locator"]
    #             for invoice in self.response.json()["generatedInvoices"]
    #         ]
    #     else:
    #         return []

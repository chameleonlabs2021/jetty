
To Create the Layer you need to 

1. Export Poetry Envirments to Requirements.txt (remove everything after the ";")

``` 
poetry export --without-hashes --without docker --format=requirements.txt > requirements.txt
```

2. Install dependencies in the locally in the env folder.

```
cd ./settings/layers/env

pip install -t ./python/lib/python3.10/site-packages -r requirements.txt
```

3. Add Proper Template to `serverless.yml`

```
layers:
  MigrationEnvrioment:
    path: ./src_lambda/layers/env
    compatibleRuntimes:
      - python3.10
    description: Migration processor enviroment layer
    package:
      include:
        - ./src_lambda/layers/env
```

> DO NOT EXCLUDE ALL FILES. Exclude do not overrides
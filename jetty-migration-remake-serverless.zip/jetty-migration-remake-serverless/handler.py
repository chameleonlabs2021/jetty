import json


def hello(event, context):
    import boto3
    import jsonpickle

    body = {
        "message": "Go Serverless v3.0! Your function executed successfully!",
        "input": event,
    }
    print(dir(context.clientContext))

    return {"statusCode": 200, "body": json.dumps(body)}
